export async function getProducts(
  categoryId?: number,
  offset = 0,
  limit = 10,
  priceMin?: number,
  priceMax?: number
) {
  const params = new URLSearchParams();
  if (priceMin !== undefined) {
    params.set('price_min', String(priceMin));
  }

  if (priceMax !== undefined) {
    params.set('price_max', String(priceMax));
  }

  if (categoryId) {
    params.set('categoryId', String(categoryId));
  }

  params.set('offset', String(offset));
  params.set('limit', String(limit));

  const response = await fetch(
    `https://api.escuelajs.co/api/v1/products?${params.toString()}`
  );

  if (!response.ok) {
    throw new Error('Failed to fetch products');
  }

  return response.json();
}
export async function getCategories() {
  const response = await fetch('https://api.escuelajs.co/api/v1/categories');

  if (!response.ok) {
    throw new Error('Failed to fetch categories');
  }

  return response.json();
}
