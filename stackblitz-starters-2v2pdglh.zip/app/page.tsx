import { getProducts, getCategories } from './actions/products';
import FacetSidebar from './components/FacetSidebar';
import ProductGrid from './components/ProductGrid';

export default async function Home({
  searchParams,
}: {
  searchParams: {
    categoryId?: string;
    price_min?: string;
    price_max?: string;
    sort?: string;
  };
}) {
  const categoryId = searchParams.categoryId
    ? Number(searchParams.categoryId)
    : undefined;
  const priceMin = searchParams.price_min
    ? Number(searchParams.price_min)
    : undefined;

  const priceMax = searchParams.price_max
    ? Number(searchParams.price_max)
    : undefined;
  const sort = searchParams.sort || 'recommended';

  const products = await getProducts(categoryId, 0, 10, priceMin, priceMax);
  const categories = await getCategories();
  const allProducts = await getProducts(undefined, 0, 100);

  const filteredCount = allProducts.filter((product: any) => {
    if (categoryId !== undefined && product.category?.id !== categoryId) {
      return false;
    }

    if (priceMin !== undefined && product.price < priceMin) {
      return false;
    }

    if (priceMax !== undefined && product.price > priceMax) {
      return false;
    }

    return true;
  }).length;

  return (
    <main>
      <nav className="mb-4 text-sm text-gray-500">Men's / Shop by Category</nav>
      <div className="my-8">
        <p className="text-sm">{filteredCount} Items</p>
      </div>

      <h1 className="text-3xl font-semibold">Men's Jackets & Vests</h1>

      <div className="mt-4 flex gap-6 text-sm">
        <span>Jackets</span>
        <span>Vests</span>
        <span>Insulation</span>
      </div>

      <div className="flex flex-col gap-8 lg:flex-row">
        <FacetSidebar
          categories={categories}
          products={allProducts}
          priceMin={priceMin}
          priceMax={priceMax}
        />

        <div className="flex-1">
          <ProductGrid
            products={products}
            categoryId={categoryId}
            priceMin={priceMin}
            priceMax={priceMax}
            sort={sort}
          />
        </div>
      </div>
    </main>
  );
}
