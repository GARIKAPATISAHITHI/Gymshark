'use client';

import { useState } from 'react';
import { getProducts } from '../actions/products';
import ProductCard from './ProductCard';

type Product = {
  id: number;
  title: string;
  price: number;
  images: string[];
};

type ProductGridProps = {
  products: Product[];
  categoryId?: number;
  priceMin?: number;
  priceMax?: number;
  sort: string;
};

export default function ProductGrid({
  products: initialProducts,
  categoryId,
  priceMin,
  priceMax,
  sort,
}: ProductGridProps) {
  const [products, setProducts] = useState(initialProducts);
  const [loading, setLoading] = useState(false);
  const [offset, setOffset] = useState(initialProducts.length);
  const [hasMore, setHasMore] = useState(true);

  const handleLoadMore = async () => {
    setLoading(true);

    try {
      const newProducts = await getProducts(
        categoryId,
        offset,
        10,
        priceMin,
        priceMax
      );

      if (newProducts.length < 10) {
        setHasMore(false);
      }

      setOffset((currentOffset) => currentOffset + newProducts.length);

      setProducts((currentProducts) => [...currentProducts, ...newProducts]);
    } finally {
      setLoading(false);
    }
  };

  const filteredProducts = products.filter((product) => {
    if (priceMin !== undefined && product.price < priceMin) {
      return false;
    }

    if (priceMax !== undefined && product.price > priceMax) {
      return false;
    }

    return true;
  });

  const sortedProducts = [...filteredProducts].sort((a, b) => {
    if (sort === 'price-low') {
      return a.price - b.price;
    }

    if (sort === 'price-high') {
      return b.price - a.price;
    }

    return 0;
  });

  return (
    <>
      <div className="mb-6 flex justify-end">
        <select
          className="border p-2 text-sm"
          value={sort}
          onChange={(event) => {
            const params = new URLSearchParams(window.location.search);

            params.set('sort', event.target.value);

            window.location.href = `/?${params.toString()}`;
          }}
        >
          <option value="recommended">Sort By</option>
          <option value="price-low">Price: Low to High</option>
          <option value="price-high">Price: High to Low</option>
        </select>
      </div>

      <div className="grid grid-cols-2 gap-6 md:grid-cols-3 lg:grid-cols-4">
        {sortedProducts.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>

      {hasMore && (
        <div className="mt-8 flex justify-center">
          <button
            type="button"
            onClick={handleLoadMore}
            disabled={loading}
            className="border px-6 py-3 text-sm"
          >
            {loading ? 'Loading...' : 'Load more'}
          </button>
        </div>
      )}
    </>
  );
}
