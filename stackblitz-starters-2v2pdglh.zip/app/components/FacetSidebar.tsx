'use client';

import { useState } from 'react';

const facets = [
  'Category',
  'Size',
  'Price',
  'Colour',
  'Materials',
  'Warmth',
  'Fit',
  'Sport',
  'Product Family',
];

export default function FacetSidebar({
  categories,
  products,
  priceMin,
  priceMax,
}: {
  categories: any[];
  products: any[];
  priceMin?: number;
  priceMax?: number;
}) {
  const [openFacet, setOpenFacet] = useState<string | null>(null);
  const handleCategoryClick = (categoryId: number) => {
    const params = new URLSearchParams(window.location.search);

    params.set('categoryId', String(categoryId));

    window.location.href = `/?${params.toString()}`;
  };

  const handleClearFilters = () => {
    window.location.href = '/';
  };
  const handlePriceFilter = (min: number, max: number) => {
    const params = new URLSearchParams(window.location.search);

    params.set('price_min', String(min));
    params.set('price_max', String(max));

    window.location.href = `/?${params.toString()}`;
  };

  return (
    <aside className="w-full lg:w-64">
      <button
        type="button"
        onClick={handleClearFilters}
        className="mb-4 text-sm underline"
      >
        Clear all filters
      </button>
      {facets.map((facet) => (
        <div key={facet} className="border-b">
          <button
            type="button"
            className="flex w-full items-center justify-between py-4 text-left font-medium"
            onClick={() => setOpenFacet(openFacet === facet ? null : facet)}
          >
            <span>{facet}</span>
            <span>{openFacet === facet ? '−' : '+'}</span>
          </button>

          {openFacet === facet && (
            <div className="pb-4 text-sm text-gray-600">
              {facet === 'Category' ? (
                <div className="space-y-2">
                  {categories.map((category) => {
                    const count = products.filter((product) => {
                      if (product.category?.id !== category.id) {
                        return false;
                      }

                      if (priceMin !== undefined && product.price < priceMin) {
                        return false;
                      }

                      if (priceMax !== undefined && product.price > priceMax) {
                        return false;
                      }

                      return true;
                    }).length;

                    return (
                      <button
                        key={category.id}
                        type="button"
                        onClick={() => handleCategoryClick(category.id)}
                        className="flex w-full items-center justify-between py-1 text-left hover:underline"
                      >
                        <span>{category.name}</span>
                        <span>({count})</span>
                      </button>
                    );
                  })}
                </div>
              ) : facet === 'Price' ? (
                <div className="space-y-2">
                  <button
                    type="button"
                    onClick={() => handlePriceFilter(0, 50)}
                    className="block w-full text-left hover:underline"
                  >
                    Under $50
                  </button>

                  <button
                    type="button"
                    onClick={() => handlePriceFilter(50, 100)}
                    className="block w-full text-left hover:underline"
                  >
                    $50 - $100
                  </button>

                  <button
                    type="button"
                    onClick={() => handlePriceFilter(100, 200)}
                    className="block w-full text-left hover:underline"
                  >
                    $100 - $200
                  </button>
                </div>
              ) : (
                <p>Filter options will go here.</p>
              )}
            </div>
          )}
        </div>
      ))}
    </aside>
  );
}
