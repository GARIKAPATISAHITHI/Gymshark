'use client';

import { useState } from 'react';

type Product = {
  id: number;
  title: string;
  price: number;
  images: string[];
};

type ProductCardProps = {
  product: Product;
};

export default function ProductCard({ product }: ProductCardProps) {
  const [imageError, setImageError] = useState(false);

  return (
    <article className="border p-4">
      {imageError || !product.images?.[0] ? (
        <div className="flex h-64 w-full items-center justify-center bg-gray-100 text-sm text-gray-400">
          Image unavailable
        </div>
      ) : (
        <img
          src={product.images[0]}
          alt={product.title}
          className="h-64 w-full object-cover"
          width={300}
          height={300}
          onError={() => setImageError(true)}
        />
      )}

      <h2 className="mt-3 text-sm font-medium">{product.title}</h2>

      <p className="mt-2 text-sm">${product.price}</p>
    </article>
  );
}
